package br.gov.sp.impactar.user.dto;

import java.time.Instant;
import java.util.UUID;

import br.gov.sp.impactar.user.Role;
import br.gov.sp.impactar.user.User;

public record UserResponse(
        UUID id,
        String name,
        String email,
        Role role,
        boolean active,
        boolean mustChangePassword,
        Instant createdAt
) {

    public static UserResponse from(User user) {
        return new UserResponse(
                user.getId(),
                user.getName(),
                user.getEmail(),
                user.getRole(),
                user.isActive(),
                user.isMustChangePassword(),
                user.getCreatedAt());
    }
}
